// firebase-config.js
export const firebaseConfig = {
  apiKey: "AIzaSyDUpX6rbzLZVjPOCdsuE7PRsUYOWfjTWNg",
  authDomain: "circus-poker.firebaseapp.com",
  projectId: "circus-poker",
  storageBucket: "circus-poker.appspot.com",
  messagingSenderId: "352050411687",
  appId: "1:352050411687:web:5f1afc49f8006cb2088382"
};
